#ifndef BALA_H
#define BALA_H

#include "meteorito.h"

class Bala: public Meteorito
{
    using Meteorito::Meteorito;
};

#endif // BALA_H
