/********************************************************************************
** Form generated from reading UI file 'ventanamodojuego.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VENTANAMODOJUEGO_H
#define UI_VENTANAMODOJUEGO_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_VentanaModoJuego
{
public:
    QAction *actionSobrePersonajes;
    QWidget *centralwidget;
    QPushButton *modoMultijugador;
    QPushButton *modoIndividual;
    QLabel *label;
    QMenuBar *menubar;
    QMenu *menuOpciones;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *VentanaModoJuego)
    {
        if (VentanaModoJuego->objectName().isEmpty())
            VentanaModoJuego->setObjectName(QString::fromUtf8("VentanaModoJuego"));
        VentanaModoJuego->resize(700, 520);
        VentanaModoJuego->setMinimumSize(QSize(700, 520));
        VentanaModoJuego->setMaximumSize(QSize(700, 520));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(114, 10, 240, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(179, 116, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(146, 63, 247, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(57, 5, 120, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(76, 6, 160, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush7(QColor(184, 132, 247, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        QBrush brush8(QColor(255, 255, 220, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush9(QColor(0, 0, 0, 128));
        brush9.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        VentanaModoJuego->setPalette(palette);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/iconos/Iconos/iconW_nave.png"), QSize(), QIcon::Normal, QIcon::Off);
        VentanaModoJuego->setWindowIcon(icon);
        actionSobrePersonajes = new QAction(VentanaModoJuego);
        actionSobrePersonajes->setObjectName(QString::fromUtf8("actionSobrePersonajes"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/iconos/Iconos/icon_info_personaje.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSobrePersonajes->setIcon(icon1);
        centralwidget = new QWidget(VentanaModoJuego);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        modoMultijugador = new QPushButton(centralwidget);
        modoMultijugador->setObjectName(QString::fromUtf8("modoMultijugador"));
        modoMultijugador->setGeometry(QRect(140, 360, 188, 41));
        modoMultijugador->setMinimumSize(QSize(188, 41));
        modoMultijugador->setMaximumSize(QSize(188, 41));
        modoMultijugador->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: #8c0391;\n"
"	border-width: 3px;\n"
"    border-color: beige;\n"
"    font: bold 14px;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"}"));
        modoIndividual = new QPushButton(centralwidget);
        modoIndividual->setObjectName(QString::fromUtf8("modoIndividual"));
        modoIndividual->setGeometry(QRect(370, 360, 188, 41));
        modoIndividual->setMinimumSize(QSize(188, 41));
        modoIndividual->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: #8c0391;\n"
"	border-width: 3px;\n"
"    border-color: beige;\n"
"    font: bold 14px;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"}"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 70, 641, 231));
        VentanaModoJuego->setCentralWidget(centralwidget);
        menubar = new QMenuBar(VentanaModoJuego);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 700, 21));
        menuOpciones = new QMenu(menubar);
        menuOpciones->setObjectName(QString::fromUtf8("menuOpciones"));
        VentanaModoJuego->setMenuBar(menubar);
        statusbar = new QStatusBar(VentanaModoJuego);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        VentanaModoJuego->setStatusBar(statusbar);

        menubar->addAction(menuOpciones->menuAction());
        menuOpciones->addAction(actionSobrePersonajes);

        retranslateUi(VentanaModoJuego);

        QMetaObject::connectSlotsByName(VentanaModoJuego);
    } // setupUi

    void retranslateUi(QMainWindow *VentanaModoJuego)
    {
        VentanaModoJuego->setWindowTitle(QApplication::translate("VentanaModoJuego", "VOYAGERS", nullptr));
        actionSobrePersonajes->setText(QApplication::translate("VentanaModoJuego", "About players", nullptr));
        modoMultijugador->setText(QApplication::translate("VentanaModoJuego", "Multiplayer", nullptr));
        modoIndividual->setText(QApplication::translate("VentanaModoJuego", "Single player", nullptr));
        label->setText(QApplication::translate("VentanaModoJuego", "<html><head/><body><p><img src=\":/V1/Fondos/ModoJuego.jpg\"/></p></body></html>", nullptr));
        menuOpciones->setTitle(QApplication::translate("VentanaModoJuego", "Options", nullptr));
    } // retranslateUi

};

namespace Ui {
    class VentanaModoJuego: public Ui_VentanaModoJuego {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VENTANAMODOJUEGO_H
